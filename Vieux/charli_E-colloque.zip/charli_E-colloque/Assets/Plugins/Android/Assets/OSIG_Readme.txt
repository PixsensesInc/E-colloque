PLACE YOUR OCULUS SIGNATURE FILES (osig) IN THIS DIRECTORY

To generate the unique signature file for your device, please visit:
https://developer.oculus.com/osig/